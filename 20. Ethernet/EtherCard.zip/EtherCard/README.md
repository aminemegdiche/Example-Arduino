**EtherCard** is a driver for the ENC28J60 chip, compatible with Arduino IDE.

Adapted and extended from code written by Guido Socher and Pascal Stang.

The home page for this library is at <http://jeelabs.net/projects/ethercard/wiki>.

License: GPL2
